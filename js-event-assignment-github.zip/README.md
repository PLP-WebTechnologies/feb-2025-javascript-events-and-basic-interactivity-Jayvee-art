# 🎯 JavaScript Event Handling & Interactive Elements

This project is a fun and interactive playground to practice core JavaScript skills: event handling, DOM manipulation, form validation, dark mode, modal popups, and localStorage!

## 💡 Features

- Button click, hover, keypress, double-click events
- Image gallery with hover animation
- Tabs & accordions
- Modal popup
- Dark mode toggle
- Form validation and localStorage
- Real-time input saving

## 📁 File Structure

```
.
├── index.html       # Main page with HTML structure
├── style.css        # Styling (light/dark mode, animations, layout)
├── script.js        # All the interactivity lives here
└── README.md        # This documentation
```

## 🚀 How to Run

Just open `index.html` in your browser. No setup required!

## 🔥 Screenshot

![screenshot](https://via.placeholder.com/800x400?text=Interactive+JavaScript+App)

## 📜 License

MIT
